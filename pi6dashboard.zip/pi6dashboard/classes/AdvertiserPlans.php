<?php


class AdvertiserPlans
{
    private $id;
    private $pi6_id_advertiser;
    private $pi6_id_plans;
    private $pi6_id_form_of_payment;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getPi6IdAdvertiser()
    {
        return $this->pi6_id_advertiser;
    }

    /**
     * @param mixed $pi6_id_advertiser
     */
    public function setPi6IdAdvertiser($pi6_id_advertiser)
    {
        $this->pi6_id_advertiser = $pi6_id_advertiser;
    }

    /**
     * @return mixed
     */
    public function getPi6IdPlans()
    {
        return $this->pi6_id_plans;
    }

    /**
     * @param mixed $pi6_id_plans
     */
    public function setPi6IdPlans($pi6_id_plans)
    {
        $this->pi6_id_plans = $pi6_id_plans;
    }

    /**
     * @return mixed
     */
    public function getPi6IdFormOfPayment()
    {
        return $this->pi6_id_form_of_payment;
    }

    /**
     * @param mixed $pi6_id_form_of_payment
     */
    public function setPi6IdFormOfPayment($pi6_id_form_of_payment)
    {
        $this->pi6_id_form_of_payment = $pi6_id_form_of_payment;
    }


}