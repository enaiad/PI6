<?php


class Country
{
    private $id_country;
    private $name_country;

    /**
     * @return mixed
     */
    public function getIdCountry()
    {
        return $this->id_country;
    }

    /**
     * @param mixed $id_country
     */
    public function setIdCountry($id_country)
    {
        $this->id_country = $id_country;
    }

    /**
     * @return mixed
     */
    public function getNameCountry()
    {
        return $this->name_country;
    }

    /**
     * @param mixed $name_country
     */
    public function setNameCountry($name_country)
    {
        $this->name_country = $name_country;
    }


}