<?php


class State
{
    private $id_state;
    private $name_state;
    private $uf;
    private $id_country;

    /**
     * @return mixed
     */
    public function getIdState()
    {
        return $this->id_state;
    }

    /**
     * @param mixed $id_state
     */
    public function setIdState($id_state)
    {
        $this->id_state = $id_state;
    }

    /**
     * @return mixed
     */
    public function getNameState()
    {
        return $this->name_state;
    }

    /**
     * @param mixed $name_state
     */
    public function setNameState($name_state)
    {
        $this->name_state = $name_state;
    }

    /**
     * @return mixed
     */
    public function getUf()
    {
        return $this->uf;
    }

    /**
     * @param mixed $uf
     */
    public function setUf($uf)
    {
        $this->uf = $uf;
    }

    /**
     * @return mixed
     */
    public function getIdCountry()
    {
        return $this->id_country;
    }

    /**
     * @param mixed $id_country
     */
    public function setIdCountry($id_country)
    {
        $this->id_country = $id_country;
    }


}