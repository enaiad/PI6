<?php


class Usr
{
    private $id_usr;
    private $usr_name;
    private $password;
    private $datecreate;
    private $lastaccess;
    private $id_advertiser;

    /**
     * @return mixed
     */
    public function getIdUsr()
    {
        return $this->id_usr;
    }

    /**
     * @param mixed $id_usr
     */
    public function setIdUsr($id_usr)
    {
        $this->id_usr = $id_usr;
    }

    /**
     * @return mixed
     */
    public function getUsrName()
    {
        return $this->usr_name;
    }

    /**
     * @param mixed $usr_name
     */
    public function setUsrName($usr_name)
    {
        $this->usr_name = $usr_name;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @return mixed
     */
    public function getDatecreate()
    {
        return $this->datecreate;
    }

    /**
     * @param mixed $datecreate
     */
    public function setDatecreate($datecreate)
    {
        $this->datecreate = $datecreate;
    }

    /**
     * @return mixed
     */
    public function getLastaccess()
    {
        return $this->lastaccess;
    }

    /**
     * @param mixed $lastaccess
     */
    public function setLastaccess($lastaccess)
    {
        $this->lastaccess = $lastaccess;
    }

    /**
     * @return mixed
     */
    public function getIdAdvertiser()
    {
        return $this->id_advertiser;
    }

    /**
     * @param mixed $id_advertiser
     */
    public function setIdAdvertiser($id_advertiser)
    {
        $this->id_advertiser = $id_advertiser;
    }


}