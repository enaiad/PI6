<?php


class Advertiser
{
    private $id_advertiser;
    private $firstname;
    private $lastname;
    private $cpf;
    private $rg;
    private $telephone_number_one;
    private $telephone_number_two;
    private $date_of_birth;
    private $address;
    private $street_number;
    private $id_city;

    /**
     * @return mixed
     */
    public function getIdAdvertiser()
    {
        return $this->id_advertiser;
    }

    /**
     * @param mixed $id_advertiser
     */
    public function setIdAdvertiser($id_advertiser)
    {
        $this->id_advertiser = $id_advertiser;
    }

    /**
     * @return mixed
     */
    public function getFirstname()
    {
        return $this->firstname;
    }

    /**
     * @param mixed $firstname
     */
    public function setFirstname($firstname)
    {
        $this->firstname = $firstname;
    }

    /**
     * @return mixed
     */
    public function getLastname()
    {
        return $this->lastname;
    }

    /**
     * @param mixed $lastname
     */
    public function setLastname($lastname)
    {
        $this->lastname = $lastname;
    }

    /**
     * @return mixed
     */
    public function getCpf()
    {
        return $this->cpf;
    }

    /**
     * @param mixed $cpf
     */
    public function setCpf($cpf)
    {
        $this->cpf = $cpf;
    }

    /**
     * @return mixed
     */
    public function getRg()
    {
        return $this->rg;
    }

    /**
     * @param mixed $rg
     */
    public function setRg($rg)
    {
        $this->rg = $rg;
    }

    /**
     * @return mixed
     */
    public function getTelephoneNumberOne()
    {
        return $this->telephone_number_one;
    }

    /**
     * @param mixed $telephone_number_one
     */
    public function setTelephoneNumberOne($telephone_number_one)
    {
        $this->telephone_number_one = $telephone_number_one;
    }

    /**
     * @return mixed
     */
    public function getTelephoneNumberTwo()
    {
        return $this->telephone_number_two;
    }

    /**
     * @param mixed $telephone_number_two
     */
    public function setTelephoneNumberTwo($telephone_number_two)
    {
        $this->telephone_number_two = $telephone_number_two;
    }

    /**
     * @return mixed
     */
    public function getDateOfBirth()
    {
        return $this->date_of_birth;
    }

    /**
     * @param mixed $date_of_birth
     */
    public function setDateOfBirth($date_of_birth)
    {
        $this->date_of_birth = $date_of_birth;
    }

    /**
     * @return mixed
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @param mixed $address
     */
    public function setAddress($address)
    {
        $this->address = $address;
    }

    /**
     * @return mixed
     */
    public function getStreetNumber()
    {
        return $this->street_number;
    }

    /**
     * @param mixed $street_number
     */
    public function setStreetNumber($street_number)
    {
        $this->street_number = $street_number;
    }

    /**
     * @return mixed
     */
    public function getIdCity()
    {
        return $this->id_city;
    }

    /**
     * @param mixed $id_city
     */
    public function setIdCity($id_city)
    {
        $this->id_city = $id_city;
    }


}