<?php


class City
{
    private $id_city;
    private $name_city;
    private $pi6_id_state;

    /**
     * @return mixed
     */
    public function getIdCity()
    {
        return $this->id_city;
    }

    /**
     * @param mixed $id_city
     */
    public function setIdCity($id_city)
    {
        $this->id_city = $id_city;
    }

    /**
     * @return mixed
     */
    public function getNameCity()
    {
        return $this->name_city;
    }

    /**
     * @param mixed $name_city
     */
    public function setNameCity($name_city)
    {
        $this->name_city = $name_city;
    }

    /**
     * @return mixed
     */
    public function getPi6IdState()
    {
        return $this->pi6_id_state;
    }

    /**
     * @param mixed $pi6_id_state
     */
    public function setPi6IdState($pi6_id_state)
    {
        $this->pi6_id_state = $pi6_id_state;
    }


}