<?php


class FormPayment
{

    private $id_form_of_payment;
    private $name_payment;

    /**
     * @return mixed
     */
    public function getIdFormOfPayment()
    {
        return $this->id_form_of_payment;
    }

    /**
     * @param mixed $id_form_of_payment
     */
    public function setIdFormOfPayment($id_form_of_payment)
    {
        $this->id_form_of_payment = $id_form_of_payment;
    }

    /**
     * @return mixed
     */
    public function getNamePayment()
    {
        return $this->name_payment;
    }

    /**
     * @param mixed $name_payment
     */
    public function setNamePayment($name_payment)
    {
        $this->name_payment = $name_payment;
    }



}