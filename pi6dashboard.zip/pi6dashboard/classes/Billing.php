<?php


class Billing
{
    private $id_billing;
    private $id_advertiser_plans_id;
    private $id_status;

    /**
     * @return mixed
     */
    public function getIdBilling()
    {
        return $this->id_billing;
    }

    /**
     * @param mixed $id_billing
     */
    public function setIdBilling($id_billing)
    {
        $this->id_billing = $id_billing;
    }

    /**
     * @return mixed
     */
    public function getIdAdvertiserPlansId()
    {
        return $this->id_advertiser_plans_id;
    }

    /**
     * @param mixed $id_advertiser_plans_id
     */
    public function setIdAdvertiserPlansId($id_advertiser_plans_id)
    {
        $this->id_advertiser_plans_id = $id_advertiser_plans_id;
    }

    /**
     * @return mixed
     */
    public function getIdStatus()
    {
        return $this->id_status;
    }

    /**
     * @param mixed $id_status
     */
    public function setIdStatus($id_status)
    {
        $this->id_status = $id_status;
    }



}