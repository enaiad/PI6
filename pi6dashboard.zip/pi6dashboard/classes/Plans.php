<?php


class Plans
{
    private $id_plans;
    private $name_plan;
    private $number_of_plans;
    private $value;

    /**
     * @return mixed
     */
    public function getIdPlans()
    {
        return $this->id_plans;
    }

    /**
     * @param mixed $id_plans
     */
    public function setIdPlans($id_plans)
    {
        $this->id_plans = $id_plans;
    }

    /**
     * @return mixed
     */
    public function getNamePlan()
    {
        return $this->name_plan;
    }

    /**
     * @param mixed $name_plan
     */
    public function setNamePlan($name_plan)
    {
        $this->name_plan = $name_plan;
    }

    /**
     * @return mixed
     */
    public function getNumberOfPlans()
    {
        return $this->number_of_plans;
    }

    /**
     * @param mixed $number_of_plans
     */
    public function setNumberOfPlans($number_of_plans)
    {
        $this->number_of_plans = $number_of_plans;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @param mixed $value
     */
    public function setValue($value)
    {
        $this->value = $value;
    }


}