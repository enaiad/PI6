<?php


class PaymentStatus
{
    private $id_status;
    private $name_status;

    /**
     * @return mixed
     */
    public function getIdStatus()
    {
        return $this->id_status;
    }

    /**
     * @param mixed $id_status
     */
    public function setIdStatus($id_status)
    {
        $this->id_status = $id_status;
    }

    /**
     * @return mixed
     */
    public function getNameStatus()
    {
        return $this->name_status;
    }

    /**
     * @param mixed $name_status
     */
    public function setNameStatus($name_status)
    {
        $this->name_status = $name_status;
    }


}